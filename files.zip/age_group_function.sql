-- 年代別顧客数を集計する関数
CREATE OR REPLACE FUNCTION get_age_group_stats()
RETURNS TABLE(age_group TEXT, count BIGINT)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT
    age_group,
    COUNT(*) as count
  FROM customers
  WHERE age_group IS NOT NULL
  GROUP BY age_group
  ORDER BY age_group;
$$;
